package org.example

fun main() {
    val computer = Computer()

    computer.loadROM()
    computer.startCpu()
}